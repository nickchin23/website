<!DOCTYPE HTML>
<?php
   include("config.php");
   session_start();      
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myusername = mysqli_real_escape_string($db,$_POST['username']);
      $mypassword = mysqli_real_escape_string($db,$_POST['password']); 
      
      $sql = "SELECT username FROM user WHERE username = '$myusername' and password = '$mypassword'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['username'];
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
        // session_register("myusername");
         $_SESSION['login_user'] = $myusername;
         
         header("location: index.html");
      }else {
         $error = "Your Login Name or Password is invalid";
      }
   }
?>
<html>
   <head>
      <title>Login Page</title>
	  <link rel="stylesheet" type="text/css" href="css/websitestyle.css">
      
   </head>
   
   <body class="login-body">
	<div class="place">
      <div align = "center">
         <div style = "width:600px; height: 280px; background-color: gray; border: solid 1px #333333; " align = "center;">
            <div class="top-bar-box"><b>Login</b></div>
				
            <div style = "text-align: center; padding-top:50px; ">
               
               <form action = "" method = "post">
                  <label style="color: white; font-size: 28px;" >UserName  :</label><input type = "text" name = "username" class = "box"/><br /><br />
                  <label style="color: white; font-size: 28px;">Password  :</label><input type = "password" name = "password" class = "box" /><br/><br />
                  <input  class="button" type = "submit" value = " Submit "/><br />
               </form>
               
               <div style = "font-size:11px; color:#cc0000; margin-top:10px"><?php //echo $error; ?></div>
					
            </div>
				
         </div>
			
      </div>
	</div>
   </body>
</html>